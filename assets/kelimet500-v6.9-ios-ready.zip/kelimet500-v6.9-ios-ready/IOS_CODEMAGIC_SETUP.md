# Kelimet500 — iOS + Codemagic checklist

Bundle ID: `com.beskentertainment.kelimet500`

## A. AdMob iOS IDs

AdMob > Apps > Add app > iOS. The app is not in the App Store yet, so choose the unpublished/not-listed option and use the final bundle ID `com.beskentertainment.kelimet500`.

You need **two different IDs**:

1. **AdMob App ID** — contains `~`
   - Example shape: `ca-app-pub-1234567890123456~1234567890`
   - Codemagic variable: `ADMOB_IOS_APP_ID`
2. **Banner Ad Unit ID** — contains `/`
   - AdMob > Kelimet500 > Ad units > Add ad unit > Banner
   - Example shape: `ca-app-pub-1234567890123456/1234567890`
   - Codemagic variable: `VITE_ADMOB_IOS_BANNER_ID`

For local testing put them in `.env.local`. For Codemagic put them in the `kelimet500_mobile` environment group.

Keep `VITE_ADMOB_TEST_MODE=true` for the first TestFlight builds. The app will deliberately use Google's test banner while this is true. Set it to `false` only for the final App Store production build.

## B. Apple Developer / App Store Connect

1. Apple Developer > Certificates, Identifiers & Profiles > Identifiers > `+` > App IDs > App.
2. Bundle ID: `com.beskentertainment.kelimet500` (Explicit).
3. Enable **Associated Domains** so Kelimet500 Universal Links can be signed correctly.
4. App Store Connect > My Apps > `+` > New App.
5. Platform: iOS. Name: Kelimet500. Pick the bundle ID above. Use any unique SKU, e.g. `kelimet500-ios-001`.
6. App Store Connect > Users and Access > Integrations > App Store Connect API > `+`.
7. Create a dedicated key, e.g. `Codemagic Kelimet500`, with **App Manager** access.
8. Download the `.p8` key once and note its **Key ID** and **Issuer ID**.
9. In the Kelimet500 App Store Connect record, General > App Information shows the numeric **Apple ID**. Save it as Codemagic variable `APP_STORE_APPLE_ID` (optional for the first build, useful for store links/versioning later).
10. Apple Developer membership Team ID goes into `APPLE_TEAM_ID`. Also put this value in Netlify when Universal Links are enabled for the public website.

## C. Codemagic connection

1. Push this project to a Git repository (GitHub is fine). `codemagic.yaml` must stay in the repository root.
2. Codemagic > Add application > connect/select the repository.
3. Codemagic Team settings > Integrations / Developer Portal > add the App Store Connect API key from section B.
4. Name the integration **exactly**: `kelimet500_appstore` (this is what `codemagic.yaml` references).
5. Codemagic > Environment variables > create a group named **exactly**: `kelimet500_mobile`.
6. Add at minimum:

```
ADMOB_IOS_APP_ID=ca-app-pub-...~...
VITE_ADMOB_IOS_BANNER_ID=ca-app-pub-.../...
VITE_ADMOB_TEST_MODE=true
VITE_PUBLIC_APP_URL=https://kelimet500.boraeskicioglu.com/
APPLE_TEAM_ID=YOUR_TEAM_ID
APP_STORE_APPLE_ID=YOUR_NUMERIC_APPLE_ID
```

7. If your final logo is not already committed, place it at `assets/logo.png` (square, ideally 1024x1024+). The iOS workflow generates the native icon automatically.
8. Open Codemagic application > Start new build > choose workflow **Kelimet500 iOS (TestFlight IPA)**.

## D. What the workflow does

The `kelimet500-ios` workflow:

1. validates AdMob/environment values,
2. installs npm packages using Node 22,
3. builds the React/Vite app,
4. creates/syncs the Capacitor 8 iOS project through Swift Package Manager,
5. generates the native app icon from `assets/logo.png`,
6. patches AdMob App ID, deep links and Associated Domains entitlement,
7. asks Codemagic to fetch/apply App Store signing files for the bundle ID,
8. sets a unique build number,
9. builds a signed IPA with Xcode 26.6,
10. uploads the IPA to App Store Connect / TestFlight automatically.

The workflow does **not** submit the app to App Store review; TestFlight comes first.

## E. After the first successful build

- App Store Connect > TestFlight: wait for processing, then add the build to Internal Testing.
- Test the banner layout, splash, saves, friend challenge deep links and consent flow on a real iPhone.
- Before final App Store submission, configure AdMob Privacy & messaging/UMP and complete App Privacy disclosures/privacy policy.
- For the actual production binary set `VITE_ADMOB_TEST_MODE=false` and keep your real AdMob IDs configured.
