# Kelimet500 reklam kurulumu

## Web (Netlify / AdSense)

Yerleşimler kodda hazırdır:

- Masaüstü > 1050 px: oyun alanının solunda ve sağında dikey slot.
- Mobil web <= 767 px: ekranın altında yatay banner.
- 768–1050 px aralığında oyun alanını sıkıştırmamak için reklam gösterilmez.

`.env.example` dosyasındaki publisher ve slot ID'lerini Netlify Environment Variables olarak ekle:

- `VITE_ADSENSE_CLIENT`
- `VITE_ADSENSE_LEFT_SLOT`
- `VITE_ADSENSE_RIGHT_SLOT`
- `VITE_ADSENSE_MOBILE_SLOT`

Yeni build/deploy sonrası slotlar otomatik aktif olur.

## Android / iOS native

Web AdSense slotları Capacitor native çalışırken bilinçli olarak kapalıdır. Native tarafta AdMob adaptive bottom banner kullanılacak.

Bunun için sonraki native build aşamasında gerekenler:

1. Android AdMob App ID
2. Android Banner Ad Unit ID
3. iOS AdMob App ID
4. iOS Banner Ad Unit ID
5. Consent/UMP ve iOS tracking tercihi

Geliştirme sırasında mutlaka test reklamı kullanılmalı; production ad unit ID'leri yayın öncesinde açılmalı.
