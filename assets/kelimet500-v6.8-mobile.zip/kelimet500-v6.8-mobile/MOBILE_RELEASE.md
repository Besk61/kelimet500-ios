# Kelimet500 v0.6 — Android + iOS release guide

Bundle / package ID for both stores: `com.beskentertainment.kelimet500`

Public challenge/share URL: `https://kelimet500.boraeskicioglu.com/`

## 1. Requirements

Capacitor 8 and the AdMob v8 plugin use Node 22+. Use Node 22 on Windows and in CI.

```powershell
nvm install 22.22.0
nvm use 22.22.0
node -v
npm install
```

The project intentionally does not commit generated native folders. `npm run mobile:android` / `npm run mobile:ios` create them on the first run, then sync them on later runs.

## 2. AdMob IDs

Create two apps in AdMob using the same application identity:

- Android package: `com.beskentertainment.kelimet500`
- iOS bundle ID: `com.beskentertainment.kelimet500`

Create one adaptive banner ad unit for Android and one for iOS.

For local development copy `.env.mobile.example` to `.env.local`.

```env
VITE_PUBLIC_APP_URL=https://kelimet500.boraeskicioglu.com/
VITE_ADMOB_ANDROID_BANNER_ID=YOUR_ANDROID_BANNER_AD_UNIT_ID
VITE_ADMOB_IOS_BANNER_ID=YOUR_IOS_BANNER_AD_UNIT_ID
VITE_ADMOB_TEST_MODE=true
```

The native AdMob **App IDs** are also read from `.env.local` by the native patch script:

```env
ADMOB_ANDROID_APP_ID=ca-app-pub-...~...
ADMOB_IOS_APP_ID=ca-app-pub-...~...
```

You may also provide these as normal process/Codemagic environment variables; process variables take precedence.

If an ID is missing, the setup script deliberately writes Google's sample/test IDs, and the TypeScript banner code uses Google's test banner IDs. Keep `VITE_ADMOB_TEST_MODE=true` during development.

Before a store release, set the real app IDs and banner IDs and set `VITE_ADMOB_TEST_MODE=false`.

Also configure the GDPR/UMP privacy message in the AdMob console before serving production ads in regions where consent is required.

## 3. Android — local Windows build

First generation / sync:

```powershell
npm run mobile:android
```

This command:

1. builds the Vite app,
2. creates the Capacitor Android project if it does not exist,
3. runs `cap sync`,
4. inserts the AdMob App ID,
5. prepares release version/signing hooks for Codemagic.

Open it in Android Studio:

```powershell
npx cap open android
```

Or make a debug APK from PowerShell:

```powershell
cd android
.\gradlew.bat assembleDebug
```

Debug APK:

`android/app/build/outputs/apk/debug/app-debug.apk`

Every time web code changes, return to the project root and run:

```powershell
npm run mobile:android
```

### Play Store

Upload an `.aab`, not the debug APK. `codemagic.yaml` includes an Android workflow that produces a signed release AAB.

In Codemagic upload an Android keystore with the reference name:

`kelimet500_keystore`

The YAML `android_signing` section exposes the signing values to the generated Gradle project. The Gradle patch only enables release signing when Codemagic's signing environment exists, so normal local debug builds keep working.

For a new personal Play Console account, start the Closed testing track as soon as the first AAB is ready. Keep at least 12 testers continuously opted in for 14 days before requesting production access.

## 4. iOS — Codemagic

Apple submission is handled completely in Codemagic; the old local Mac is not needed for the release build.

### App Store Connect preparation

1. Create the Bundle ID `com.beskentertainment.kelimet500` in Apple Developer.
2. Create a new app in App Store Connect using the same bundle ID.
3. In Codemagic, add an App Store Connect API integration. The provided YAML expects the integration name:
   `kelimet500_appstore`
4. Configure automatic iOS code signing for the same bundle ID.

### Codemagic environment group

Create an environment variable group named:

`kelimet500_mobile`

Add:

```text
ADMOB_ANDROID_APP_ID
ADMOB_IOS_APP_ID
VITE_ADMOB_ANDROID_BANNER_ID
VITE_ADMOB_IOS_BANNER_ID
VITE_ADMOB_TEST_MODE
VITE_PUBLIC_APP_URL
```

For a release build use:

```text
VITE_ADMOB_TEST_MODE=false
VITE_PUBLIC_APP_URL=https://kelimet500.boraeskicioglu.com/
```

The iOS workflow uses Xcode 26.6, Capacitor 8's Swift Package Manager project, App Store distribution signing, and `xcode-project build-ipa`.

On its first run it executes `npm run mobile:ios`, which creates `ios/`, syncs Capacitor plugins through Swift Package Manager, inserts the AdMob App ID / SKAdNetwork entries, applies App Store provisioning profiles, increments the build number and builds the IPA.

The workflow uploads a successful IPA to App Store Connect/TestFlight automatically (`submit_to_testflight: true`) but does not submit it to App Store review. Internal TestFlight distribution can then be handled in App Store Connect.

## 5. Codemagic workflows

`codemagic.yaml` contains:

- `kelimet500-android` → signed `.aab`
- `kelimet500-ios` → signed `.ipa` and App Store Connect upload

Connect the Git repository to Codemagic and choose the workflow you want to run.

### Android variables/signing

- Keystore reference: `kelimet500_keystore`
- Env group: `kelimet500_mobile`
- `VERSION_NAME` defaults to `1.0.0`
- `BUILD_NUMBER` becomes Android `versionCode`

### iOS signing

- App Store Connect integration: `kelimet500_appstore`
- Bundle ID: `com.beskentertainment.kelimet500`
- Xcode: 26.6
- Scheme: `App`
- Xcode project: `App.xcodeproj` (Capacitor 8 SPM)

## 6. Native behavior already handled

- Web AdSense slots are hidden inside native apps.
- Android/iOS use a native AdMob adaptive bottom banner.
- The layout reserves the real banner height so the ad does not cover the keyboard/game UI.
- UMP consent is checked before requesting an ad.
- Google test ad IDs are the safe default.
- Native Share Sheet is used on Android/iOS.
- Friend challenge links always point to the public Kelimet500 website rather than `capacitor://localhost`.
- The existing localStorage game saves continue to work inside the Capacitor WebView.

## 7. Before production submission

Do these before the final store upload:

- replace test AdMob IDs with production IDs,
- configure AdMob Privacy & messaging / UMP,
- prepare final app icon and launch/splash artwork,
- complete Play Data safety and App Store App Privacy disclosures for the AdMob SDK,
- add privacy policy URL to both store listings,
- test challenge sharing, daily saves, banner layout and consent on physical Android/iOS devices,
- keep Google test ads enabled on dev/test builds.

The next useful release task is generating the final icon/splash assets and store screenshots once the native builds have been smoke-tested.

## v0.6.5 branding + deep links

- Native launch screen is followed by an animated React splash.
- Put the final logo at `assets/logo.png` and run `npm run branding:apply` after native platforms exist.
- Friend URLs use `https://kelimet500.boraeskicioglu.com/challenge/<token>`.
- Android App Links and iOS Universal Links are patched automatically into generated native projects.
- Web association files are generated during `npm run build` from `ANDROID_APP_LINK_SHA256` and `APPLE_TEAM_ID`.
- See `DEEP_LINK_SETUP.md` before enabling production links.
