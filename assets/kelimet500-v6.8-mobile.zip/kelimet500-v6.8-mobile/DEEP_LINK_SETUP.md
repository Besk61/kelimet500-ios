# Kelimet500 Challenge App Links

Challenge URL formatı:

`https://kelimet500.boraeskicioglu.com/challenge/<token>`

Amaç:

- Uygulama kuruluysa Android App Links / iOS Universal Links ile Kelimet500 açılır.
- Uygulama kurulu değilse webde yalnızca mağaza yönlendirme ekranı açılır; challenge browser içinde oynatılmaz.
- Doğrulama çalışmazsa fallback olarak `kelimet500://challenge/<token>` custom scheme'i de kayıtlıdır.

## Android

Native patch `AndroidManifest.xml` içine `android:autoVerify="true"` App Link filtresi ekler.

Web tarafında şu dosya gerekir:

`/.well-known/assetlinks.json`

Dosya `npm run build` sırasında `scripts/generate-link-associations.mjs` ile üretilir.

Netlify environment variable:

`ANDROID_APP_LINK_SHA256`

Play App Signing kullanıyorsan burada **upload key değil**, Play Console > App integrity bölümündeki **App signing key certificate SHA-256** parmak izini kullan.

Birden fazla fingerprint gerekiyorsa virgülle ayırabilirsin.

## iOS

Native patch şunları ekler:

- `App.entitlements`
- `applinks:kelimet500.boraeskicioglu.com`
- `CODE_SIGN_ENTITLEMENTS`
- `kelimet500://` fallback URL scheme

Apple Developer portalında `com.beskentertainment.kelimet500` App ID için **Associated Domains** capability açık olmalı. Sonrasında provisioning profile yeniden oluşturulmalı / Codemagic yeni profile kullanmalı.

Web tarafında:

`/.well-known/apple-app-site-association`

üretilir.

Netlify environment variable:

`APPLE_TEAM_ID`

Örnek: `ABCD123456`

## Store fallback

Netlify build environment'a ekle:

`VITE_ANDROID_STORE_URL=https://play.google.com/store/apps/details?id=com.beskentertainment.kelimet500`

`VITE_IOS_STORE_URL=https://apps.apple.com/app/idXXXXXXXXXX`

Store kayıtları çıkana kadar boş bırakılabilir. Boşken fallback sayfası “yakında” mesajı gösterir.

## Netlify

`public/_redirects` `/challenge/*` yollarını React uygulamasına yönlendirir.

`public/_headers` association dosyalarını `application/json` olarak sunar.

`ANDROID_APP_LINK_SHA256` ve `APPLE_TEAM_ID` değerlerini Netlify'a girdikten sonra siteyi yeniden deploy et.
