import { useEffect, useMemo } from 'react';
import { appSchemeUrlForToken } from './deepLinks';

type Props = { token: string };

function platformFromUserAgent() {
  const ua = navigator.userAgent.toLowerCase();
  if (/android/.test(ua)) return 'android';
  if (/iphone|ipad|ipod/.test(ua)) return 'ios';
  return 'desktop';
}

export function ChallengeInstallLanding({ token }: Props) {
  const platform = useMemo(platformFromUserAgent, []);
  const androidStore = import.meta.env.VITE_ANDROID_STORE_URL || '';
  const iosStore = import.meta.env.VITE_IOS_STORE_URL || '';
  const preferredStore = platform === 'android' ? androidStore : platform === 'ios' ? iosStore : '';

  useEffect(() => {
    if (!preferredStore) return;
    const timer = window.setTimeout(() => window.location.replace(preferredStore), 1300);
    return () => window.clearTimeout(timer);
  }, [preferredStore]);

  const tryOpenApp = () => {
    window.location.href = appSchemeUrlForToken(token);
    if (preferredStore) {
      window.setTimeout(() => window.location.assign(preferredStore), 1200);
    }
  };

  return (
    <main className="challenge-install-page">
      <div className="challenge-install-card">
        <div className="challenge-install-logo">K <span>500</span></div>
        <p className="challenge-kicker">ARKADAŞ MEYDAN OKUMASI</p>
        <h1>Sana özel bir kelime bırakıldı 😁</h1>
        <p>Bu meydan okuma Kelimet500 uygulamasında açılır. Uygulama kuruluysa bağlantı normalde doğrudan oyunu açar.</p>
        <button className="challenge-install-primary" onClick={tryOpenApp}>KELİMET500’Ü AÇ</button>
        {androidStore && <a href={androidStore}>Google Play’den indir</a>}
        {iosStore && <a href={iosStore}>App Store’dan indir</a>}
        {!androidStore && !iosStore && (
          <div className="challenge-coming-soon">Mobil mağaza bağlantıları yakında burada olacak.</div>
        )}
        <small>Kelime bu web sayfasında oynatılmaz; bağlantı uygulamaya aktarılır.</small>
      </div>
    </main>
  );
}
